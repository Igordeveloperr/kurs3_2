﻿namespace DBAdmin.DTO
{
    public class ApartmentDTO
    {
        public int Id { get; set; }
        public string Address {  get; set; }
    }
}
