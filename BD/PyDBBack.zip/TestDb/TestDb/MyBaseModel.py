from sqlalchemy.orm import DeclarativeBase

class MyBaseModel(DeclarativeBase): pass